
void read_game_list_config();
void save_game_list_config();
int do_game_sel(int);

#ifdef __cplusplus
extern "C"
#endif
void done_game_selection();
