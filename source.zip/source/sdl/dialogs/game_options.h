int do_game_options(int sel);


