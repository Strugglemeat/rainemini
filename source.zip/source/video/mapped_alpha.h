
#undef ARG_MAP
#define ARG_MAP UINT8 *SPR, int x, int y, UINT8 *cmap
void Draw16x16_Trans_Mapped_Alpha_8(ARG_MAP);
void Draw16x16_Trans_Mapped_Alpha_8_FlipY(ARG_MAP);
void Draw16x16_Trans_Mapped_Alpha_8_FlipX(ARG_MAP);
void Draw16x16_Trans_Mapped_Alpha_8_FlipXY(ARG_MAP);

void Draw16x16_Trans_Mapped_Alpha_16(ARG_MAP);
void Draw16x16_Trans_Mapped_Alpha_16_FlipY(ARG_MAP);
void Draw16x16_Trans_Mapped_Alpha_16_FlipX(ARG_MAP);
void Draw16x16_Trans_Mapped_Alpha_16_FlipXY(ARG_MAP);

void Draw16x16_Trans_Mapped_Alpha_32(ARG_MAP);
void Draw16x16_Trans_Mapped_Alpha_32_FlipY(ARG_MAP);
void Draw16x16_Trans_Mapped_Alpha_32_FlipX(ARG_MAP);
void Draw16x16_Trans_Mapped_Alpha_32_FlipXY(ARG_MAP);

void Draw16x16_Mapped_Alpha_8(ARG_MAP);
void Draw16x16_Mapped_Alpha_8_FlipY(ARG_MAP);
void Draw16x16_Mapped_Alpha_8_FlipX(ARG_MAP);
void Draw16x16_Mapped_Alpha_8_FlipXY(ARG_MAP);

void Draw16x16_Mapped_Alpha_16(ARG_MAP);
void Draw16x16_Mapped_Alpha_16_FlipY(ARG_MAP);
void Draw16x16_Mapped_Alpha_16_FlipX(ARG_MAP);
void Draw16x16_Mapped_Alpha_16_FlipXY(ARG_MAP);

void Draw16x16_Mapped_Alpha_32(ARG_MAP);
void Draw16x16_Mapped_Alpha_32_FlipY(ARG_MAP);
void Draw16x16_Mapped_Alpha_32_FlipX(ARG_MAP);
void Draw16x16_Mapped_Alpha_32_FlipXY(ARG_MAP);
