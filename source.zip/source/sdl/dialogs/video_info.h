
int do_video(int );

