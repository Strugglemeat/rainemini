#define HAVE_6502 0
#define HAVE_68000 1
#define HAVE_Z80 0
