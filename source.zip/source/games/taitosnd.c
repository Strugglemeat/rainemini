#include "gameinc.h"
#include "taitosnd.h"
#include "fm.h"
//#include "sasound.h"            // sample support routines
#include "2151intf.h"
#include "adpcm.h"
#include "timer.h"
#include "streams.h"

static UINT8 *ROMBANK=NULL;	// Pointer to start of z80 rom bank data
static UINT8 *BANKLIST[8];	// Pointers to start of each bank (0-7)


/************************************************************/

// YM2151 Handler
// --------------
static int reg2151;

UINT16 YM2151ReadZ80(UINT16 offset)
{
#if 0
  if( (offset&0x01) ){
    return YM2151_status_port_0_r(0);
  } else
    return 0;
#else

  static int ta=0;
  ta^=255;
  return(ta);

#endif
}

UINT16 YM2151ReadZ80_Timer(UINT16 offset)
{
#if 1
  if( (offset&0x01) ){
    return YM2151_status_port_0_r(0);
  } else
    return 0;
#else

  static int ta=0;
  ta^=255;
  return(ta);

#endif
}

void YM2151WriteZ80(UINT16 offset, UINT8 data)
{
   if((offset&1)==0){
      reg2151=data;
   }
   else{
     YM2151_register_port_0_w(offset,reg2151);	// It's faster to wait for the data like this!!
     YM2151_data_port_0_w(offset,data);
   }
}

// Banking via YM2151 - TAITO

void YM2151TaitoWriteZ80(UINT16 offset, UINT8 data)
{

   if((offset&1)==0){
      reg2151=data;
   }
   else{
      if(reg2151==0x1B){
	// TaitoSoundSetBank(offset, (UINT8) ((data>>6)&3) );
      }
      YM2151_register_port_0_w(offset,reg2151); // It's faster to wait for the data like this!!
      YM2151_data_port_0_w(offset,data);
   }
}


static struct YM2151interface ym2151_interface =
{
  1,			// 1 chip
  4000000,		// 4 MHz
  { YM3012_VOL(160,OSD_PAN_LEFT,160,OSD_PAN_RIGHT) },
  { z80_irq_handler },
  { NULL }
};

struct SOUND_INFO taito_ym2151_sound[] =
{
   { SOUND_YM2151J, &ym2151_interface,	},
   { 0, 	    NULL,		},
};

void Taito2151_Frame(void)
{
   execute_z80_audio_frame();
}

void Taito2151_FrameFast(void)
{
   cpu_execute_cycles(CPU_Z80_0, CPU_FRAME_MHz(6,60));	// Z80 6MHz (60fps)
   /*#ifdef RAINE_DEBUG
     print_debug("Z80PC0:%04x\n",z80pc);
#endif*/
   cpu_interrupt(CPU_Z80_0, 0x38);
}

void Taito2151_FrameRI(void)
{

   cpu_execute_cycles(CPU_Z80_0, CPU_FRAME_MHz(6,60));	// Z80 6MHz (60fps)
   /*#ifdef RAINE_DEBUG
     print_debug("Z80PC0:%04x\n",z80pc);
#endif*/
   cpu_interrupt(CPU_Z80_0, 0x38);
}

void Taito2151_Frame_xsystem(void)
{
/*     cpu_execute_cycles(CPU_Z80_0, CPU_FRAME_MHz(8,60));	// Z80 8MHz (60fps) */
/*     cpu_interrupt(CPU_Z80_0, 0x38); */
      execute_z80_audio_frame();
}

/*

more recent memory map:

 - it resembles the ym2610 one
 - banking is not via ym2151
 - no nmi (nmi will reset the cpu)
 - ym30xx volume and panning support?

*/

void RemoveTaitoYM2151(void)
{
  // RemoveTaitoSoundBanking();
}

static struct OKIM6295interface m6295_interface =
{
   1,					// 1 chip
   { 8500 },				// rate
   { 0 },		// rom list
   { 250 },
};

struct SOUND_INFO taito_ym2203_m6295_sound[] =
{
//   { SOUND_YM2203,  &ym2203_interface,	},
   { SOUND_M6295,   &m6295_interface,	},
   { 0, 	    NULL,		},
};

void M6295_Init(UINT8 *src, UINT32 size)
{
  ADPCMSetBuffers(((struct ADPCMinterface*)&m6295_interface),src,0x40000);
}

/**********************************************************/

// First OKI 6295

void M6295_A_Write_68k( UINT32 address, UINT16 data )
{
  OKIM6295_data_0_w( 0, data&0xFF );
}

UINT16 M6295_A_Read_68k( UINT32 address )
{
  return 0; //OKIM6295_status_0_r( 0 );
}

void M6295_A_WriteBank_68k(UINT32 address,UINT16 data) { // bankswitch
  OKIM6295_bankswitch(0,data);
}

// Second OKI 6295

void M6295_B_Write_68k( UINT32 address, UINT16 data )
{
  OKIM6295_data_1_w( 1, data&0xFF );
}

UINT16 M6295_B_Read_68k( UINT32 address )
{
  return 0; //OKIM6295_status_1_r( 1 );
}

void M6295_B_WriteBank_68k( UINT32 address, UINT16 data ){
  OKIM6295_bankswitch(1,data);
}

/**********************************************************/

// First OKI 6295

void M6295_A_Write_Z80(UINT16 offset, UINT8 data)
{
  OKIM6295_data_0_w( 0, data );
}

UINT16 M6295_A_Read_Z80(UINT16 offset)
{
  return OKIM6295_status_0_r( 0 );
}

UINT16 M6295_A_ReadFree_Z80(UINT16 offset)
{
   return(0x00);
}

void M6295_A_WriteBank_Z80(UINT16 offset, UINT8 data){
  OKIM6295_bankswitch(0,data);
}
