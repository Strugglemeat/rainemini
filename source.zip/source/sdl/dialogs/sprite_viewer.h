#if SDL==1
#ifdef __cplusplus
extern "C" {
#endif

int sprite_viewer(int sel);

#ifdef __cplusplus
}
#endif
#endif
