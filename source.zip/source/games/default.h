
#ifdef __cplusplus
extern "C" {
#endif

void LoadDefault(void);
void ClearDefault(void);
void DrawDefault(void);
void ExecuteDefaultFrame(void);


#ifdef __cplusplus
}
#endif
