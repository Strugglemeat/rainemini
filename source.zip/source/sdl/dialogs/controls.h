
int do_controls(int);
