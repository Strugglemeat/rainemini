int do_video_options(int);

