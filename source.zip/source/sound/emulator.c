#include "sasound.h"
#include "2151intf.h"
#include "adpcm.h"
#include "m6585.h"
#include "streams.h"
#include "debug.h"
#include "5220intf.h"


int change_sample_rate;

/* Warning : this array must be in the same order as the enum inittype in sasound.h (declaration of the SOUND_xxx constants */
struct SOUND_CHIP sound_chip_list[] = // Not static for dlg_about.c
{
#if HAS_YM2151
   { "ym2151",     YM2151_sh_stop,        },
#endif
#if HAS_YM2151_ALT
   { "ym2151",     YM2151_sh_stop,        },
#endif
#if HAS_ADPCM
   { "m6295",      OKIM6295_sh_stop,   },
#endif
   { "sn76496",    NULL,                  },
#if HAS_M6585
   { "m6585",      M6585buffer_sh_stop,   },
#endif
#if HAS_DAC
   { "dac", NULL },
#endif
   { NULL,	   NULL,		  },
};

char *get_sound_chip_name(UINT32 id)
{
    // SOUND_NONE is now 0, but the sound_chip_list still starts at 0
   return sound_chip_list[id-1].name;
}

static int emulators_active = 0;

int init_sound_emulators(void)
{
   int i,j;

   if(change_sample_rate)
      saStopSoundEmulators();
   if (emulators_active)
     return 0;

   change_sample_rate = 0;
   if( SndMachine ){
    if( !SndMachine->first ){
      saInitVolPan();		/* moved. (hiro-shi) */
      SndMachine->first = 1;	/* first flag clear */
      streams_sh_start();	/* streaming system initialize & start */
      for( j = 0; j < SndMachine->control_max; j++ ){
	switch( SndMachine->init[j] ){


#if HAS_YM2151
	case SOUND_YM2151S:
		  i = YM2151_sh_start( SndMachine->intf[j] );
	break;
#endif
#if HAS_YM2151_ALT
	case SOUND_YM2151J:
	  i = YM2151_sh_start( SndMachine->intf[j] );
	break;
#endif
#if HAS_ADPCM
	case SOUND_M6295:
	  i = OKIM6295_sh_start( SndMachine->intf[j] );
	break;
#endif
#if HAS_M6585
	case SOUND_M6585:
	  i = M6585buffer_sh_start( SndMachine->intf[j] );
	break;
#endif


	default:
	  i = 1;
	break;
	}
	if( i ){
	  SndMachine = NULL;
	  printf("emulator init failed\n");
	  return 1;
	}
      }
    }
  }
   emulators_active = 1;
  return 0;
}

/*********************************************************************/
/* stop sound emulators: this is needed for when sample rate changes */
/*********************************************************************/
void saStopSoundEmulators(void)
{
   int i;
   print_debug("SaStopSoundEmulators()\n");

   emulators_active = 0;
   saResetPlayChannels();
   if( SndMachine == NULL ){
      SndMachine = &snd_entry;
   }
   else{
     if(SndMachine->first!=0){		// YM3812 fix crashes
       streams_sh_stop();
       for( i = 0; i < SndMachine->control_max; i++ ){

	 if( SndMachine->init[i] && sound_chip_list[SndMachine->init[i]-1].shutdown )
	   sound_chip_list[SndMachine->init[i]-1].shutdown();
       }
       SndMachine->first	   = 0;
     }
   }
}
