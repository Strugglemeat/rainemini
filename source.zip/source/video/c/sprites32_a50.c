#include "deftypes.h"
#include "raine.h"
#include "blit.h"
#include "alpha.h"
#include "alpha50.h"

render(32,32,ReadLong);
