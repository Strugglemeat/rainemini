#ifdef __cplusplus
extern "C" {
#endif

int do_cheats(int sel);

#ifdef __cplusplus
}
#endif
