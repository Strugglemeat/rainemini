#include "gui/menu.h"

extern TMenu *gui_options;

int do_gui_options(int );

