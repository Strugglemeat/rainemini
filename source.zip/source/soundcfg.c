#include "raine.h"
#include "compat_sdl.h"
#include "sasound.h"

void sound_load_cfg() {
   int id;

   RaineSoundCard = 0;
#if SDL == 2
#ifdef RAINE_WIN32
   char *driver = raine_get_config_string("Sound","driver","directsound");
#else
   char *driver = raine_get_config_string("Sound","driver",NULL);
#endif
   if (driver) {
       char buf[80];
       snprintf(buf,80,"SDL_AUDIODRIVER=%s",driver);
       putenv(buf);
   }
#endif
#ifndef ALLEGRO_SOUND
   // sdl, default to sound enabled (1)
   id = raine_get_config_id(    "Sound",        "sound_card",  1);
   // id = 1; // force auto-detect ALWAYS
   // there is no reason not to autodetect the sound
#else
#ifdef RAINE_WIN32
   id = raine_get_config_id(    "Sound",        "sound_card",  DIGI_DIRECTAMX(0));
#else
   id = raine_get_config_id(    "Sound",        "sound_card",           DIGI_NONE);
#endif
   if (id > 1<<8) { // the id is really a soundcard id, not an index
     install_sound(id, MIDI_NONE, NULL);
     if (system_driver->digi_drivers)
       digi = system_driver->digi_drivers();
     else
       digi = _digi_driver_list;

     for (i=0; digi[i].driver; i++){
       if (id==((DIGI_DRIVER *)digi[i].driver)->id)
	 RaineSoundCard = i+1;
     }
     remove_sound(); // the sound is not installed here.
   } else
#endif
     RaineSoundCard = id;

   /* It's better to default to 44Khz in sdl in win32 because of the buggy sound drivers
      in this os (they oblige to have quite a big sound buffer, which produces a
      noticeable sound delay at low sampling rates */
   audio_sample_rate= raine_get_config_int( "Sound",        "sample_rate",          0 );


   // enh_stereo = raine_get_config_int( "Sound",        "enh_stereo",0 );
}

void sound_save_cfg() {
   // SOUND
#if SDL == 2
    raine_set_config_string("Sound","driver",(char*)SDL_GetCurrentAudioDriver());
#endif
   raine_set_config_id( 	"Sound",        "sound_card",           sound_card_id(RaineSoundCard));
   raine_set_config_int(	"Sound",        "sample_rate",          audio_sample_rate);
}
