
int do_romdir(int sel);

