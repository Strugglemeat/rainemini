
int do_colors(int sel);
