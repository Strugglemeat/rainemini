
#ifdef __cplusplus
extern "C" {
#endif

#include "deftypes.h"

extern struct SOUND_INFO taito_ym2151_sound[];
extern struct SOUND_INFO taito_ym2151_msm5205_sound[];

// Z80->YM2151 Communication Handlers
// ----------------------------------

UINT16 YM2151ReadZ80(UINT16 offset);
UINT16 YM2151ReadZ80_Timer(UINT16 offset);
void YM2151WriteZ80(UINT16 offset, UINT8 data);
void YM2151TaitoWriteZ80(UINT16 offset, UINT8 data);

// TAITO Generic YM2151+ADPCM+Z80 Handler
// --------------------------------------

void AddTaitoYM2151(UINT32 p1, UINT32 p2, UINT32 romsize, UINT8 *adpcmA, UINT8 *adpcmB);
void AddTaitoYM2151_Timer(UINT32 p1, UINT32 p2, UINT32 romsize, UINT8 *adpcmA, UINT8 *adpcmB);
void AddTaitoYM2151_xsystem(UINT32 p1, UINT32 p2, UINT32 romsize);

void Taito2151_Frame(void);
void Taito2151_FrameFast(void);
void Taito2151_FrameRI(void);
void Taito2151_Frame_xsystem(void);

void RemoveTaitoYM2151(void);


// First OKI 6295

void M6295_A_Write_68k( UINT32 address, UINT16 data );
UINT16 M6295_A_Read_68k( UINT32 address );
void M6295_A_WriteBank_68k( UINT32 address, UINT16 data );

void M6295_A_Write_Z80(UINT16 offset, UINT8 data);
UINT16 M6295_A_Read_Z80(UINT16 offset);
UINT16 M6295_A_ReadFree_Z80(UINT16 offset);
void M6295_A_WriteBank_Z80(UINT16 offset, UINT8 data);

// Second OKI 6295

void M6295_B_Write_68k( UINT32 address, UINT16 data );
UINT16 M6295_B_Read_68k( UINT32 address );
void M6295_B_WriteBank_68k( UINT32 address, UINT16 data );

/**************** end of file ****************/

#ifdef __cplusplus
}
#endif
