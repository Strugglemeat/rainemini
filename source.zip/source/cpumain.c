/******************************************************************************/
/*                                                                            */
/*                           CPU CALLING ROUTINES                             */
/*                                                                            */
/******************************************************************************/

#include "deftypes.h"
#include "cpumain.h"
#include "gameinc.h"

#include "games/default.h"
#include "gui.h" // goto_debuger

UINT32 current_cpu_num[0x10];
UINT32 cycles_68k[2];
static char active[4];

/*

switch to the requested cpu (context manager)

*/

void switch_cpu(UINT32 cpu_id)
{
   UINT32 new_type;
   UINT32 new_num;
   UINT32 old_id;

   new_type = cpu_id >> 4;
   new_num  = cpu_id & 0x0F;
/*
#if USE_MUSASHI == 2
   //Musashi handles the 68020 & the 68000 with only 1 context, so I must
    //switch between contexts here... 
   if (new_type == (CPU_68K_0 >> 4) && m68ki_cpu.cpu_type == CPU_TYPE_020) {
       // Only 68020 tested, will have to change if using 68EC020.
       m68k_get_context(&m68020_context);
       // This is called on init, switch_cpu(0x1f) to reset all cpu contexts
       // except f is an invald number, so at least try to to switch to an invalid cpu !
       if (StarScreamEngine > new_num)
	   m68k_set_context(&M68000_context[new_num]);
       current_cpu_num[new_type] = new_num;
       return;
   } else if (new_type == (CPU_M68020_0 >> 4) && MC68020 && m68ki_cpu.cpu_type == CPU_TYPE_000) {
       if (StarScreamEngine > new_num)
	   m68k_get_context(&M68000_context[new_num]);
       m68k_set_context(&m68020_context);
       current_cpu_num[new_type] = new_num;
       return;
   }
#endif
*/
   if( current_cpu_num[new_type] != new_num ){

      // first save the current cpu context

      old_id = (current_cpu_num[new_type]) | (new_type<<4);

      switch(old_id){
#ifdef HAVE_68000
         case CPU_68K_0:
            s68000GetContext(&M68000_context[0]);
         break;
         case CPU_68K_1:
            s68000GetContext(&M68000_context[1]);
         break;
#endif

      }

      // now load the new cpu context

      switch(cpu_id){
#if HAVE_68000
         case CPU_68K_0:
            s68000SetContext(&M68000_context[0]);
         break;
         case CPU_68K_1:
            s68000SetContext(&M68000_context[1]);
         break;
#endif


      }

      // update id

      current_cpu_num[new_type] = new_num;
   }
}

/*

initialize

*/

void start_cpu_main(void)
{
   UINT32 ta;

   for(ta=0; ta<0x10; ta++)
      current_cpu_num[ta] = 0x0F;
}

/*

uninitialize - need to do this before outside access to cpu contexts

*/

void stop_cpu_main(void)
{
  /* It fills all the cpu contexts with correct data so that they can eventually be saved */
   UINT32 ta;

   for(ta=0; ta<0x10; ta++)
      switch_cpu((ta<<4) | 0x0F);
}

/*

request an interrupt on a cpu

*/

#ifdef SDL
extern int goto_debuger;
#endif

void cpu_interrupt(UINT32 cpu_id, UINT32 vector)
{
#ifdef SDL
    if (goto_debuger) return;
#endif

   switch_cpu(cpu_id);

   switch(cpu_id){
#if HAVE_68000
      case CPU_68K_0:
      case CPU_68K_1:
#if USE_MUSASHI == 2
	  m68k_set_irq(vector);
#else
	  s68000interrupt(vector, -1);
	  // s68000flushInterrupts();
#endif
	  break;
#endif


   }
}

/*

request an nmi on a cpu

*/

void cpu_int_nmi(UINT32 cpu_id)
{
#ifdef SDL
    if (goto_debuger) return;
#endif
   switch_cpu(cpu_id);

   switch(cpu_id){
      case CPU_68K_0:
      case CPU_68K_1:
         // not available on this cpu
      break;
   }
}

/*

execute a cpu for some cycles

*/

void cpu_execute_cycles(UINT32 cpu_id, UINT32 cycles)
{
#ifdef SDL
    if (goto_debuger) return;
#endif
   switch_cpu(cpu_id);
   int ret;

   switch(cpu_id){
#if HAVE_68000
      case CPU_68K_0:
      case CPU_68K_1:
	  active[cpu_id & 0xf] = 1;
#if USE_MUSASHI == 2
	  ret = m68k_execute(cycles);
#else
         ret = s68000exec(cycles);
#endif
	  active[cpu_id & 0xf] = 0;
	 print_debug("PC:%06x SR:%04x SP:%04x\n",s68000_pc,s68000_sr,s68000_areg[7]);
#if USE_MUSASHI < 2
#ifdef RAINE_DEBUG
	 if (ret == 0x80000001) {
	     printf("starscream out of bounds\n");
	     exit(1);
	 }
	 if (ret < 0x80000000)
	     fatal_error("starscream invalid instruction at %x",ret);
	 if (s68000_pc & 0xff000000) {
	   printf("pc out of bounds for 68k%d\n",cpu_id & 15);
	 }
	 if (ret == 0xffffffff) {
	     fatal_error("starscream : double fault");
	 }
#endif
	 cycles_68k[cpu_id & 0xf] += s68000readOdometer();
	 // Musashi always resets this number of cycles returned for each call to m68k_execute
	 s68000tripOdometer(); // we just reset it here explicitely for starscream
#else
	 cycles_68k[cpu_id & 0xf] += ret; // Musashi just returns the cycles executed...
#endif
      break;
#endif

   }
}

UINT32 cpu_get_cycles_done(UINT32 cpu) {
   switch_cpu(cpu);
   switch(cpu >> 4) {
   case CPU_68000:
#if USE_MUSASHI < 2
		  return cycles_68k[cpu & 0xf] + s68000readOdometer();
#else
		  if (active[cpu & 0xf])
		      return cycles_68k[cpu & 0xf] + m68k_cycles_run();
		  else
		      return cycles_68k[cpu & 0xf];
#endif
   }
   return 0;
}

void cpu_set_cycles_done(UINT32 cpu, int cycles) {
    switch_cpu(cpu);
    switch(cpu >> 4) {
    case CPU_68000: cycles_68k[cpu & 0xf] += cycles; break;
    }
}

/*

reset a cpu

*/

void cpu_reset(UINT32 cpu_id)
{
   switch_cpu(cpu_id);

   switch(cpu_id){
#if HAVE_68000
      case CPU_68K_0:
      case CPU_68K_1:
#if USE_MUSASHI == 2
	  m68k_pulse_reset();
#else
	  s68000reset();
#endif
	  cycles_68k[cpu_id & 0xf] = 0;
      break;
#endif

   }
}

/*

get the pc of a cpu

*/

UINT32 cpu_get_pc(UINT32 cpu_id)
{
   UINT32 ret;

   switch_cpu(cpu_id);

   switch(cpu_id){
#if HAVE_68000
   case CPU_68K_0:
   case CPU_68K_1:
     ret = s68000_pc;
     break;
#endif

   default:
     ret = 0;
     break;
   }

   return ret;
}

void cpu_get_ram(UINT32 cpu, UINT32 *range, UINT32 *count) {
    switch(cpu>>4) {
#if HAVE_68000
    case CPU_68000: s68000_get_ram(cpu & 0xf,range,count); break;
#endif


    }
}

UINT8 *get_code_range(UINT32 cpu, UINT32 adr, UINT32 *start, UINT32 *end) {
    switch(cpu >> 4) {
#if HAVE_68000
    case CPU_68000:
	return s68k_get_code_range(cpu & 0xf, adr, start, end);
	break;
#endif

    }
    return NULL;
}

UINT8 *get_userdata(UINT32 cpu, UINT32 adr) {
    switch(cpu >> 4) {
#if HAVE_68000
    case 1: return s68k_get_userdata(cpu & 0xf,adr);
#endif

    }
    return NULL;
}

int bcd(int value) {
  return ((value/10)<<4) | (value % 10);
}

