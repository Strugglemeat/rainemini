#if SDL == 1
#ifdef __cplusplus
extern "C" {
#endif

int do_msg(int sel);
int do_screen(int sel);

#ifdef __cplusplus
}
#endif
#endif

